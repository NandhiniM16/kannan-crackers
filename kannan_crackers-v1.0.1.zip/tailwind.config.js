module.exports = {
  mode: "jit",
  content: ["./src/**/**/*.{js,ts,jsx,tsx,html,mdx}", "./src/**/*.{js,ts,jsx,tsx,html,mdx}"],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        blue: { 50: "#ebf4ff", A200: "#4392f1" },
        white: { A700: "#ffffff", A700_f2: "#fffffff2" },
        black: { 900: "#000000" },
        teal: { 900: "#023047" },
        blue_gray: { 100: "#d9d9d9", 200: "#bccad1", 900: "#002538", "900_01": "#2a3134", "900_02": "#313131" },
        gray: {
          200: "#f0f0f0",
          400: "#c9c4c1",
          500: "#a8a8a8",
          700: "#5d5e71",
          900: "#26292b",
          "100_02": "#f6f3f1",
          "500_01": "#ababab",
          "700_02": "#676869",
          "700_01": "#666869",
          "500_02": "#8f8f8f",
          "400_02": "#b8b8b8",
        },
      },
      boxShadow: { xs: "4px 4px 44px 5px #00000019", sm: "0px 4px 74px 0px #00000026" },
      fontFamily: { poppins: "Poppins" },
      opacity: { 0.8: 0.8 },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
