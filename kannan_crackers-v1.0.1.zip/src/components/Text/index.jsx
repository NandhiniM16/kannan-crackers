import React from "react";

const sizes = {
  xs: "text-base font-normal",
  lg: "text-2xl font-medium md:text-[22px]",
  s: "text-xl font-normal",
  "2xl": "text-[28px] font-normal md:text-[26px] sm:text-2xl",
  "3xl": "text-[32px] font-normal md:text-3xl sm:text-[28px]",
  xl: "text-[26px] font-normal md:text-2xl sm:text-[22px]",
  md: "text-[22px] font-medium",
};

const Text = ({ children, className = "", as, size = "xs", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-gray-700_02 font-poppins ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Text };
