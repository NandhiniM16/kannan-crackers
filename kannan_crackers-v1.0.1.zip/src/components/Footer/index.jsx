import React from "react";
import { Text, Button, Img, Heading } from "./..";

export default function Footer({ ...props }) {
  return (
    <footer {...props} className={`${props.className} self-stretch pt-[77px] md:pt-5 bg-teal-900`}>
      <div className="flex w-full flex-col items-center gap-[74px] md:gap-[55px] sm:gap-[37px]">
        <div className="container-xs pl-16 pr-[84px] md:p-5 md:px-5">
          <div className="flex items-start justify-between gap-5 md:flex-col">
            <div className="flex w-[50%] flex-col items-start md:w-full">
              <div className="flex w-[83%] items-start justify-between gap-5 md:w-full">
                <Img src="images/img_footer_logo.png" alt="footer logo" className="h-[70px] w-[132px] object-contain" />
                <Heading as="h4" className="!font-bold !text-gray-100_02">
                  OFFICE
                </Heading>
              </div>
              <a href="#" className="relative mt-[-2px] self-end">
                <Text size="s" as="p" className="!text-gray-400">
                  AR Crackers SIVAKASI
                </Text>
              </a>
              <div className="mt-[30px] flex items-start justify-between gap-5 self-stretch md:flex-col">
                <Text size="s" as="p" className="w-[52%] leading-[30px] !text-gray-400 md:w-full">
                  AR Crackers is the best for crackers all over the India . All we give is best and good Quality for our
                  customers. We are always available here contact us to get the best.
                </Text>
                <div className="mt-7 flex flex-col gap-[21px]">
                  <Text size="s" as="p" className="!text-gray-400">
                    info@arcrackers.com
                  </Text>
                  <Heading size="md" as="h3" className="!text-gray-400">
                    + 1234567890
                  </Heading>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-start gap-[31px]">
              <Heading as="h4" className="!font-bold !text-gray-100_02">
                LINKS
              </Heading>
              <ul className="flex flex-col items-start gap-[22px]">
                <li>
                  <a href="Home" target="_blank" rel="noreferrer">
                    <Text size="s" as="p" className="!text-gray-400">
                      Home
                    </Text>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <Text size="s" as="p" className="!text-gray-400">
                      About us
                    </Text>
                  </a>
                </li>
                <li>
                  <a href="Products" target="_blank" rel="noreferrer">
                    <Text size="s" as="p" className="!text-gray-400">
                      Products
                    </Text>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <Text size="s" as="p" className="!text-gray-400">
                      Contact Us
                    </Text>
                  </a>
                </li>
              </ul>
            </div>
            <div className="flex w-[14%] flex-col items-start gap-5 md:w-full">
              <Heading as="h4" className="!font-bold !text-gray-100_02">
                Social Links
              </Heading>
              <div className="flex justify-between gap-5 self-stretch">
                <Button className="flex h-[37px] w-[37px] items-center justify-center self-start px-1.5">
                  <Img src="images/img_volume_gray_400_01.svg" />
                </Button>
                <Button className="flex h-[37px] w-[37px] items-center justify-center self-start">
                  <Img src="images/img_overflow_menu.svg" />
                </Button>
                <Img src="images/img_facebook.svg" alt="facebook icon" className="h-[37px] w-[37px]" />
                <Button className="flex h-[37px] w-[38px] items-center justify-center self-end">
                  <Img src="images/img_info.svg" />
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-center self-stretch bg-blue_gray-900 pb-5 pt-[31px] sm:pt-5">
          <div className="container-xs flex justify-center pl-[551px] pr-[570px] md:p-5 md:px-5">
            <Text size="xl" as="p" className="!text-gray-700">
              AR Crackers @2024. ALL RIGHTS RESERVED
            </Text>
          </div>
        </div>
      </div>
    </footer>
  );
}
