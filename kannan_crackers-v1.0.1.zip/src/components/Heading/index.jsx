import React from "react";

const sizes = {
  xl: "text-[75px] font-semibold md:text-5xl",
  s: "text-2xl font-semibold md:text-[22px]",
  md: "text-3xl font-semibold md:text-[28px] sm:text-[26px]",
  xs: "text-xl font-semibold",
  lg: "text-4xl font-semibold md:text-[34px] sm:text-[32px]",
};

const Heading = ({ children, className = "", size = "s", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-teal-900 font-poppins ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Heading };
