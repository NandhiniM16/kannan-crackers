import React from "react";
import { Button, Img, Text } from "./..";

export default function Header({ ...props }) {
  return (
    <header
      {...props}
      className={`${props.className} flex justify-center items-center pt-[46px] pb-[9px] md:pt-5 bg-blue-A200`}
    >
      <div className="container-xs flex items-start justify-center md:flex-col md:p-5">
        <Img src="images/img_header_logo.png" alt="header logo" className="h-[55px] w-[106px] object-contain" />
        <ul className="!ml-[468px] !mt-2.5 flex flex-wrap items-center gap-[35px] md:ml-0">
          <li>
            <a href="#" className="flex items-center justify-center rounded-[3px] bg-blue-A200 sm:px-5">
              <Text as="p" className="px-[29px] py-1 !text-white-A700">
                Home
              </Text>
            </a>
          </li>
          <li>
            <a href="#" className="cursor-pointer sm:px-5">
              <Text
                as="p"
                className="px-[29px] py-1 !text-black-900 hover:rounded-[3px] hover:bg-blue-A200 hover:!text-white-A700"
              >
                About Us
              </Text>
            </a>
          </li>
          <li>
            <a href="#" className="cursor-pointer sm:px-5">
              <Text
                as="p"
                className="px-[29px] py-1 !text-black-900 hover:rounded-[3px] hover:bg-blue-A200 hover:!text-white-A700"
              >
                Products
              </Text>
            </a>
          </li>
          <li>
            <a href="#" className="cursor-pointer sm:px-5">
              <Text
                as="p"
                className="px-[29px] py-1 !text-black-900 hover:rounded-[3px] hover:bg-blue-A200 hover:!text-white-A700"
              >
                Contact Us
              </Text>
            </a>
          </li>
        </ul>
        <div className="ml-[285px] mt-[5px] flex w-[32%] items-center justify-between gap-5 md:ml-0 md:w-full">
          <a href="#">
            <Img src="images/img_cart.svg" alt="cart icon" className="h-[29px]" />
          </a>
          <a href="#">
            <Img src="images/img_rewind.svg" alt="rewind icon" className="h-[29px] w-[29px]" />
          </a>
          <Button
            leftIcon={<Img src="images/img_download.svg" alt="download" className="h-[24px] w-[26px]" />}
            className="flex h-[42px] min-w-[146px] flex-row items-center justify-center gap-[7px] border-2 border-solid border-blue-A200 pr-2.5 text-center text-base font-bold text-blue-A200"
          >
            BROCHURE
          </Button>
        </div>
      </div>
    </header>
  );
}
