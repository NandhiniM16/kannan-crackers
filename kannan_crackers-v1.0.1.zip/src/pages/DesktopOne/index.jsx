import React from "react";
import { Helmet } from "react-helmet";
import { CloseSVG } from "../../assets/images";
import { GoogleMap, Img, Heading, Text, Button, CheckBox, Input } from "../../components";
import Footer from "../../components/Footer";
import Header from "../../components/Header";

export default function DesktopOnePage() {
  const [searchBarValue, setSearchBarValue] = React.useState("");

  return (
    <>
      <Helmet>
        <title>Explore Our Product Catalog - AR Crackers</title>
        <meta
          name="description"
          content="Discover premium quality crackers with AR Crackers. Shop from a variety of sparklers, aerial crackers, and gift boxes at competitive prices. Fast & safe shipping available."
        />
      </Helmet>

      {/* main layout section */}
      <div className="w-full bg-white-A700">
        {/* header section */}
        <div className="flex flex-col items-center">
          {/* navigation section */}
          <div className="h-[840px] self-stretch bg-[url(/public/images/img_group_36.png)] bg-cover bg-no-repeat pb-[729px] md:h-auto md:pb-5">
            <Header />
          </div>

          {/* category search section */}
          <div className="container-xs mt-[110px] flex items-center justify-between gap-5 md:flex-col md:p-5">
            <Heading size="lg" as="h1">
              PRODUCT CATEGORIES
            </Heading>
            <div className="flex w-[41%] items-center justify-between gap-5 md:w-full md:flex-col">
              <Input
                name="Search Field"
                placeholder={`Click to Search here`}
                value={searchBarValue}
                onChange={(e) => setSearchBarValue(e)}
                suffix={
                  <div className="flex h-[55px] w-[56px] items-center justify-center rounded-[50%] bg-blue-A200">
                    {searchBarValue?.length > 0 ? (
                      <CloseSVG onClick={() => setSearchBarValue("")} height={28} width={29} />
                    ) : (
                      <Img
                        src="images/img_rewind_white_a700.svg"
                        alt="rewind"
                        className="h-[28px] w-[29px] cursor-pointer"
                      />
                    )}
                  </div>
                }
                className="flex h-[55px] w-[68%] items-center justify-center gap-[35px] rounded-[27px] border border-solid border-gray-500_01 pl-[23px] text-[17px] text-gray-500 md:w-full sm:pl-5"
              />
              <Button
                rightIcon={<Img src="images/img_vector_1.svg" alt="vector 1" className="h-[7px] w-[14px]" />}
                className="flex h-[57px] min-w-[153px] flex-row items-center justify-center gap-[27px] rounded-[3px] bg-blue-A200 px-[21px] text-center text-xl text-white-A700 sm:px-5"
              >
                English
              </Button>
            </div>
          </div>

          {/* category list section */}
          <div className="container-xs mt-[55px] flex items-center justify-center bg-gray-200 px-2.5 pb-[9px] pt-2.5 md:flex-col md:p-5">
            <Button className="flex h-[49px] min-w-[128px] flex-row items-center justify-center rounded-sm bg-blue-A200 px-[35px] text-center text-xl font-semibold text-white-A700 md:p-5 sm:px-5">
              ALL
            </Button>
            <Heading size="xs" as="h2" className="ml-[81px] !text-blue-A200 md:ml-0">
              Sound Crackers
            </Heading>
            <Heading size="xs" as="h3" className="mb-1.5 ml-[98px] self-end !text-blue-A200 md:ml-0">
              Sparklers
            </Heading>
            <Heading size="xs" as="h4" className="ml-[98px] !text-blue-A200 md:ml-0">
              Aerial Crackers
            </Heading>
            <Heading size="xs" as="h5" className="ml-[98px] !text-blue-A200 md:ml-0">
              Guns
            </Heading>
            <Heading size="xs" as="h6" className="ml-[98px] !text-blue-A200 md:ml-0">
              Match Boxes
            </Heading>
            <Heading size="xs" as="h5" className="ml-[98px] !text-blue-A200 md:ml-0">
              Nattuvedi
            </Heading>
            <Heading size="xs" as="h5" className="ml-[104px] !text-blue-A200 md:ml-0">
              Gift Boxes
            </Heading>
          </div>

          {/* product filter section */}
          <div className="container-xs mt-14 md:p-5">
            <div className="flex items-start justify-between gap-5 md:flex-col">
              <div className="flex w-[24%] flex-col justify-center bg-white-A700 px-[13px] pb-[724px] pt-[17px] shadow-xs md:w-full md:pb-5">
                <div className="flex flex-col items-start gap-4">
                  <Text size="3xl" as="p" className="ml-2 !text-blue_gray-900_01 md:ml-0">
                    Filters
                  </Text>
                  <div className="h-px w-full self-stretch bg-blue_gray-200" />
                </div>
                <div className="mt-[27px] flex w-[91%] items-start justify-between gap-5 self-center md:w-full">
                  <Text size="md" as="p">
                    Sort By
                  </Text>
                  <Img src="images/img_arrow_down.svg" alt="sort icon" className="mt-[7px] h-[8px]" />
                </div>
                <CheckBox
                  name="Alphabetical Checkbox"
                  label="Alphabetical Order"
                  id="AlphabeticalCheckbox"
                  className="ml-[11px] mt-5 flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Price Low-High Checkbox"
                  label="Low - High Price"
                  id="PriceLowHighCheckbox"
                  className="ml-[11px] mt-[21px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Price High-Low Checkbox"
                  label="High - Low Price"
                  id="PriceHighLowCheckbox"
                  className="ml-[11px] mt-[21px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Popularity Checkbox"
                  label="Popularity"
                  id="PopularityCheckbox"
                  className="ml-[11px] mt-5 flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <div className="mt-[23px]">
                  <div className="flex flex-col gap-[19px]">
                    <div className="h-px bg-blue_gray-200" />
                    <div className="flex items-start justify-between gap-5">
                      <Text size="md" as="p">
                        Brand
                      </Text>
                      <Img src="images/img_arrow_down.svg" alt="brand icon" className="mt-2.5 h-[8px]" />
                    </div>
                  </div>
                </div>
                <CheckBox
                  name="Sony Checkbox"
                  label="Sony"
                  id="SonyCheckbox"
                  className="ml-[11px] mt-[23px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Ladigo Checkbox"
                  label="Ladigo"
                  id="LadigoCheckbox"
                  className="ml-[11px] mt-5 flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Mugilan Checkbox"
                  label="Mugilan"
                  id="MugilanCheckbox"
                  className="ml-[11px] mt-[21px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <CheckBox
                  name="Ravinthra Checkbox"
                  label="Ravinthra"
                  id="RavinthraCheckbox"
                  className="ml-[11px] mt-[18px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <div className="ml-[11px] mt-[19px] flex w-[42%] items-start gap-[15px] md:ml-0 md:w-full">
                  <CheckBox
                    name="Special Checkbox"
                    label="AR Special"
                    id="SpecialCheckbox"
                    className="flex flex-1 gap-2.5 text-base text-gray-700_02"
                  />
                  <Img src="images/img_signal.svg" alt="signal icon" className="h-[17px] w-[18px]" />
                </div>
                <CheckBox
                  name="Random Checkbox"
                  label="Random Crackers"
                  id="RandomCheckbox"
                  className="ml-[11px] mt-[19px] flex gap-2.5 text-base text-gray-700_02 md:ml-0"
                />
                <div className="mt-[23px] flex flex-col gap-[18px]">
                  <div className="h-px bg-blue_gray-200" />
                  <div className="flex flex-col gap-2.5">
                    <div className="flex items-start justify-between gap-5">
                      <Text size="md" as="p">
                        Category
                      </Text>
                      <Img src="images/img_arrow_down.svg" alt="category icon" className="mt-[7px] h-[8px]" />
                    </div>
                    <div className="h-px bg-blue_gray-200" />
                  </div>
                </div>
              </div>

              {/* product grid section */}
              <div className="grid w-[71%] grid-cols-4 gap-[65px] md:grid-cols-2 sm:grid-cols-1">
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_9.png"
                      alt="product image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h2">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_frame.svg" alt="cart icon" className="h-[38px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                          <Img src="images/img_group_7.svg" alt="quantity icon" className="h-px self-end" />
                        </div>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                          <Img src="images/img_plus.svg" alt="add icon" className="h-[19px] w-[20px]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col gap-[26px]">
                  <Img
                    src="images/img_rectangle_10.png"
                    alt="second product image"
                    className="h-[235px] object-cover"
                  />
                  <div className="flex self-start">
                    <div className="flex flex-col items-start">
                      <Text size="s" as="p" className="!text-gray-900">
                        10 Cm Eletric Sparkler
                      </Text>
                      <Text as="p" className="!text-gray-700_01">
                        Quantity : 5 Box
                      </Text>
                      <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                        <Heading as="h3">Rs. 200</Heading>
                        <Text as="p" className="!text-gray-400_02">
                          Rs. 300
                        </Text>
                        <Text as="p" className="!text-blue-A200">
                          (25%)
                        </Text>
                      </div>
                      <div className="mt-[15px] flex items-center gap-[23px]">
                        <Img src="images/img_signal_amber_400.svg" alt="second cart icon" className="h-[35px]" />
                        <div className="flex gap-[27px] rounded-sm border border-solid border-gray-500_02">
                          <div className="flex items-center gap-6">
                            <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                              <Img src="images/img_group_7.svg" alt="second quantity icon" className="h-px self-end" />
                            </div>
                            <Text size="xl" as="p">
                              01
                            </Text>
                          </div>
                          <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                            <Img src="images/img_plus.svg" alt="second add icon" className="h-[19px] w-[20px]" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col items-start">
                  <div className="relative h-[235px] self-stretch md:h-auto">
                    <Img src="images/img_rectangle_11.png" alt="image" className="h-[235px] w-full object-cover" />
                    <Img
                      src="images/img_airplane.svg"
                      alt="airplane"
                      className="absolute left-[0.00px] top-[5.94px] m-auto h-[21px]"
                    />
                  </div>
                  <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                    10 Cm Eletric Sparkler
                  </Text>
                  <Text as="p" className="!text-gray-700_01">
                    Quantity : 5 Box
                  </Text>
                  <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                    <Heading as="h4">Rs. 200</Heading>
                    <Text as="p" className="!text-gray-400_02">
                      Rs. 300
                    </Text>
                    <Text as="p" className="!text-blue-A200">
                      (25%)
                    </Text>
                  </div>
                  <div className="mt-[15px] flex w-[73%] items-center justify-between gap-5 self-end rounded-sm border border-solid border-gray-500_02 md:w-full">
                    <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                      <Img src="images/img_group_7.svg" alt="image" className="h-px self-end" />
                    </div>
                    <Text size="xl" as="p">
                      01
                    </Text>
                    <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-[11px]">
                      <Img src="images/img_plus.svg" />
                    </Button>
                  </div>
                </div>
                <div className="flex w-full flex-col gap-[26px]">
                  <div className="h-[235px] bg-blue_gray-100" />
                  <div>
                    <div className="flex flex-col gap-[15px]">
                      <div className="flex">
                        <div className="flex flex-col gap-2.5">
                          <div className="flex flex-col items-start">
                            <Text size="s" as="p" className="!text-gray-900">
                              10 Cm Eletric Sparkler
                            </Text>
                            <Text as="p" className="!text-gray-700_01">
                              Quantity : 5 Box
                            </Text>
                          </div>
                          <div className="flex flex-wrap items-center gap-2.5 self-start">
                            <Heading as="h5">Rs. 200</Heading>
                            <Text as="p" className="!text-gray-400_02">
                              Rs. 300
                            </Text>
                            <Text as="p" className="!text-blue-A200">
                              (25%)
                            </Text>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-[23px]">
                        <Img src="images/img_signal_amber_400.svg" alt="signal" className="h-[35px]" />
                        <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                          <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                            <Img src="images/img_group_7.svg" alt="image" className="h-px self-end" />
                          </div>
                          <Text size="xl" as="p">
                            01
                          </Text>
                          <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                            <Img src="images/img_plus.svg" alt="plus" className="h-[19px] w-[20px]" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_14.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h6">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_frame.svg" alt="image" className="h-[38px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                          <Img src="images/img_group_7.svg" alt="image" className="h-px self-end" />
                        </div>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                          <Img src="images/img_plus.svg" alt="plus" className="h-[19px] w-[20px]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_15.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px] self-end" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-[11px]">
                          <Img src="images/img_plus.svg" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_16.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px] self-end" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                          <Img src="images/img_plus.svg" alt="plus" className="h-[19px] w-[20px]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_17.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px] self-end" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <div className="flex rounded border border-solid border-gray-500_02 px-3.5 pb-[22px] pt-6 sm:py-5">
                          <Img src="images/img_group_7.svg" alt="image" className="h-px self-end" />
                        </div>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                          <Img src="images/img_plus.svg" alt="plus" className="h-[19px] w-[20px]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_18.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_frame.svg" alt="image" className="h-[38px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-[11px]">
                          <Img src="images/img_plus.svg" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_19.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-[11px]">
                          <Img src="images/img_plus.svg" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_20.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-[11px]">
                          <Img src="images/img_plus.svg" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex w-full flex-col">
                  <div className="flex flex-col items-start">
                    <Img
                      src="images/img_rectangle_21.png"
                      alt="image"
                      className="h-[235px] w-full object-cover md:h-auto"
                    />
                    <Text size="s" as="p" className="mt-[26px] !text-gray-900">
                      10 Cm Eletric Sparkler
                    </Text>
                    <Text as="p" className="!text-gray-700_01">
                      Quantity : 5 Box
                    </Text>
                    <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                      <Heading as="h4">Rs. 200</Heading>
                      <Text as="p" className="!text-gray-400_02">
                        Rs. 300
                      </Text>
                      <Text as="p" className="!text-blue-A200">
                        (25%)
                      </Text>
                    </div>
                    <div className="mt-[15px] flex items-center gap-[23px] self-stretch">
                      <Img src="images/img_signal_amber_400_36x40.svg" alt="signal" className="h-[36px]" />
                      <div className="flex flex-1 items-center justify-between gap-5 rounded-sm border border-solid border-gray-500_02">
                        <Button className="flex h-[46px] w-[48px] items-center justify-center rounded border border-solid border-gray-500_02 p-3.5">
                          <Img src="images/img_group_7.svg" />
                        </Button>
                        <Text size="xl" as="p">
                          01
                        </Text>
                        <div className="flex rounded border border-solid border-gray-500_02 pb-[13px] pl-3.5 pr-[11px] pt-3.5">
                          <Img src="images/img_plus.svg" alt="plus" className="h-[19px] w-[20px]" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* quality shipping section */}
          <div className="relative z-[2] mt-[-3px] flex justify-center self-stretch bg-indigo-100 pb-[110px] pt-[86px] md:py-5">
            <div className="container-xs flex justify-center pl-[86px] pr-[126px] md:p-5 md:px-5">
              <div className="flex w-full flex-col items-center gap-[21px]">
                <div className="flex w-[90%] items-center justify-between gap-5 md:w-full sm:flex-col">
                  <Img
                    src="images/img_frame_20.svg"
                    alt="price image"
                    className="h-[111px] w-[110px] self-start sm:w-full"
                  />
                  <Img
                    src="images/img_frame_19.svg"
                    alt="secondary image"
                    className="mb-[17px] h-[74px] w-[12%] self-end sm:w-full"
                  />
                  <Heading
                    size="xl"
                    as="h2"
                    className="flex h-[120px] w-[120px] items-center justify-center rounded-[60px] border-4 border-solid border-blue-A200 text-center !text-blue-A200"
                  >
                    $
                  </Heading>
                  <Img src="images/img_frame_18.svg" alt="tertiary image" className="h-[120px] w-[9%] sm:w-full" />
                </div>
                <div className="flex w-[90%] flex-wrap justify-between gap-5 md:w-full">
                  <Text size="lg" as="p" className="!text-blue_gray-900_01">
                    QUALITY
                  </Text>
                  <Text size="lg" as="p" className="self-start !text-blue_gray-900_01">
                    SHIPPING
                  </Text>
                  <Text size="lg" as="p" className="self-start !text-blue_gray-900_01">
                    PRICE
                  </Text>
                  <Text size="lg" as="p" className="self-start !text-blue_gray-900_01">
                    SERVICES
                  </Text>
                </div>
                <div className="flex flex-wrap justify-between gap-5 self-stretch">
                  <Text size="s" as="p">
                    Premium Quality Crackers
                  </Text>
                  <Text size="s" as="p">
                    Fast & Safe Shipping
                  </Text>
                  <Text size="s" as="p" className="self-end">
                    Low Cost you ever Seen
                  </Text>
                  <Text size="s" as="p" className="self-start">
                    24/7 Services & Support
                  </Text>
                </div>
              </div>
            </div>
          </div>

          {/* contact social section */}
          <div className="relative h-[1003px] self-stretch">
            <Img
              src="images/img_banner_02.png"
              alt="bannertwo"
              className="absolute left-0 right-0 top-[0.00px] m-auto h-[851px] w-full object-cover"
            />
            <div className="container-xs absolute bottom-[0.00px] left-0 right-0 my-auto flex gap-[45px] md:relative md:flex-col md:p-5">
              <div className="flex w-full rounded-[5px] bg-white-A700_f2 px-[43px] pb-[104px] pt-[37px] shadow-sm md:px-5 md:pb-5 sm:p-5">
                <div className="flex w-[61%] flex-col items-start md:w-full">
                  <div className="flex items-start self-stretch">
                    <Button className="relative z-[1] mt-[77px] flex h-[49px] w-[49px] items-center justify-center rounded-[7px] bg-blue-A200 px-[11px]">
                      <Img src="images/img_call.svg" />
                    </Button>
                    <div className="relative ml-[-43px] flex flex-col items-end gap-[37px]">
                      <Text size="2xl" as="p" className="self-start !text-blue-A200">
                        Phone Number
                      </Text>
                      <Text size="3xl" as="p" className="!text-blue_gray-900_02">
                        +1234567890
                      </Text>
                      <Text size="3xl" as="p" className="!text-blue_gray-900_02">
                        +1234567890
                      </Text>
                    </div>
                  </div>
                  <Button className="relative mt-[-48px] flex h-[49px] w-[49px] items-center justify-center rounded-[7px] bg-blue-A200 px-2.5">
                    <Img src="images/img_volume.svg" />
                  </Button>
                </div>
              </div>
              <div className="flex w-full justify-center rounded-[5px] bg-white-A700_f2 pb-[103px] pl-[27px] pr-[37px] pt-[37px] shadow-sm md:pb-5 sm:p-5">
                <div className="flex flex-col items-start gap-[37px]">
                  <Text size="2xl" as="p" className="!text-blue-A200">
                    Social
                  </Text>
                  <div className="flex items-center gap-[17px]">
                    <Button className="flex h-[49px] w-[49px] items-center justify-center rounded-[7px] bg-blue-A200 px-[7px]">
                      <Img src="images/img_lock.svg" />
                    </Button>
                    <Text size="3xl" as="p" className="!text-blue_gray-900_02">
                      info@arcrackers.com
                    </Text>
                  </div>
                  <div className="flex items-center gap-[17px]">
                    <Button className="flex h-[49px] w-[49px] items-center justify-center rounded-[7px] bg-blue-A200 px-[7px]">
                      <Img src="images/img_globe.svg" />
                    </Button>
                    <Text size="3xl" as="p" className="self-start !text-blue_gray-900_02">
                      www.arcrackers.com
                    </Text>
                  </div>
                </div>
              </div>
              <div className="flex w-full rounded-[5px] bg-white-A700_f2 pb-24 pl-[27px] pr-[22px] pt-[37px] shadow-sm md:pb-5 sm:p-5">
                <div className="flex w-full flex-col items-start gap-[35px]">
                  <Text size="2xl" as="p" className="!text-blue-A200">
                    Address
                  </Text>
                  <div className="flex items-start gap-3.5 self-stretch sm:flex-col">
                    <Button className="flex h-[49px] w-[49px] items-center justify-center rounded-[7px] bg-blue-A200 px-[7px]">
                      <Img src="images/img_linkedin.svg" />
                    </Button>
                    <Text size="3xl" as="p" className="w-[89%] leading-[48px] !text-blue_gray-900_02 sm:w-full">
                      AR Crackers, Ravinthra Gate By passroad sivakasi 626189
                    </Text>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* brand showcase section */}
          <div className="container-xs mt-[153px] flex flex-col items-center gap-6 pl-[88px] pr-[92px] md:p-5 md:px-5">
            <Heading size="lg" as="h2">
              OUR BRANDS
            </Heading>
            <Img
              src="images/img_brands_1.png"
              alt="brand image"
              className="h-[192px] w-full object-cover opacity-0.8 md:h-auto"
            />
          </div>

          {/* location map section */}
          <GoogleMap showMarker={false} className="mt-28 h-[475px] self-stretch" />

          {/* footer section */}
          <Footer />
        </div>
      </div>
    </>
  );
}
